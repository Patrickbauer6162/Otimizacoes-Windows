# 📺 Vídeos de Referência — HSRoficial

Canal: [youtube.com/@HSRoficial](https://www.youtube.com/@HSRoficial)

Todos os tweaks deste repositório foram documentados a partir dos vídeos públicos do canal.

---

## 🎬 Vídeos Usados Como Base

| Tweak | Vídeo | Ano |
|---|---|---|
| DisableDynamicPstate (GPU clock máximo) | COMANDO REGEDIT PARA MAIS DESEMPENHO NOS JOGOS | 2023 |
| NetworkThrottling + SystemResponsiveness + GPU Priority | COMANDOS REGEDIT PARA MAIS DESEMPENHO VOL. 2 | 2022 |
| Regedit Vol. 3 (múltiplos tweaks) | COMANDOS REGEDIT PARA MAIS DESEMPENHO VOL. 3 | 2022 |
| Input Lag Mouse e Teclado (`mouclass`/`kbdclass`) | COMANDO REGEDIT PARA MENOS INPUT LAG NOS JOGOS | 2024 |
| DisableHDCP (`RMHdcpKeyglobZero`) | OTIMIZAR O PC COM COMANDO REGEDIT (DESATIVE AGORA) | 2024 |
| Desativar MPO (`OverlayTestMode`) | COMO AUMENTAR FPS DESATIVANDO MPO NO REGEDIT | 2024 |
| SvchostSplitThresholdInKB por RAM | COMANDO REGEDIT PARA OTIMIZAR O PC E TER MAIS DESEMPENHO | 2025 |
| CpuPriorityClass (prioridade por .exe) | Arquivo compartilhado pelo usuário | — |

---

## 📋 Playlists do Canal

- **Otimizações gerais:** [Playlist no YouTube](https://www.youtube.com/@HSRoficial)
- **Otimizações por jogo:** disponível no canal

---

## 🔗 Contato do Criador

- 📸 Instagram: [instagram.com/hsroficial](https://instagram.com/hsroficial)
- 🔊 Discord: [discord.gg/HSRoficial](https://discord.gg/tHCGy4K2Hj)
- 👾 Twitch: [twitch.tv/hsroficial](https://twitch.tv/hsroficial)

> O criador também oferece **otimizações particulares** para PCs e notebooks.  
> Entre em contato pelo Instagram para mais informações.
