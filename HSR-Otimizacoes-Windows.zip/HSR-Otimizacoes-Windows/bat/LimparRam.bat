@echo off
title HSRoficial - Limpeza de RAM

echo ==========================================
echo   Limpeza de Memoria RAM
echo   HSRoficial - youtube.com/@HSRoficial
echo ==========================================
echo.
echo Liberando memoria RAM ociosa...
echo.

:: Esvazia o Working Set de todos os processos
%SystemRoot%\system32\rundll32.exe advapi32.dll,ProcessIdleTasks

echo [OK] Memoria liberada com sucesso!
echo.
echo Dica: Use antes de abrir um jogo pesado.
echo.
pause
