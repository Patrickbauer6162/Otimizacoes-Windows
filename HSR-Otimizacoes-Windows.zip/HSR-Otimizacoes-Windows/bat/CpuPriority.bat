@echo off
setlocal

title Configurar CpuPriorityClass

echo ==========================================
echo  Configurador de Prioridade de CPU
echo ==========================================
echo.

set /p EXE=Digite o nome do executavel (ex: jogo.exe):

echo.
echo Niveis disponiveis:
echo 1 = Idle
echo 2 = Normal
echo 3 = High
echo 4 = Realtime
echo 5 = Below Normal
echo 6 = Above Normal
echo.

set /p PRIORIDADE=Digite o valor da prioridade:

if "%EXE%"=="" (
echo Nome do executavel invalido.
pause
exit /b
)

reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options%EXE%\PerfOptions" ^
/v CpuPriorityClass ^
/t REG_DWORD ^
/d %PRIORIDADE% ^
/f

if errorlevel 1 (
echo.
echo Erro ao alterar o Registro.
echo Execute este arquivo como Administrador.
) else (
echo.
echo Configuracao aplicada com sucesso!
echo.
echo Executavel: %EXE%
echo CpuPriorityClass: %PRIORIDADE%
)

pause
